#include "HelloGL.h"

int main(int argc, char* argv[])
{
	HelloGL* game = new HelloGL(argc, argv);// creates instance of game

	return 0; // assumes a successful exit if game exists
}